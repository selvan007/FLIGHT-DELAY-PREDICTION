from flask import Flask, render_template, request
import pandas as pd
import joblib
import numpy as np

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/form')
def form():
    return render_template('Flightdelay.html') 

@app.route('/result', methods=['POST'])
def predict():
    fl_num = int(request.form.get('fno'))
    month = int(request.form.get('month'))
    dayofmonth = int(request.form.get('daym'))
    dayofweek = int(request.form.get('dayw'))
    sdeptime = request.form.get('sdt')
    adeptime = request.form.get('adt')
    arrtime = int(request.form.get('sat'))
    depdelay = int(adeptime) - int(sdeptime)
    
    inputs = []
    inputs.append(fl_num)
    inputs.append(month)
    inputs.append(dayofmonth)
    inputs.append(dayofweek)
    inputs.append(0 if depdelay < 15 else 1)
    inputs.append(arrtime)

    origin = str(request.form.get("org"))
    if origin == "ATL":
        inputs.extend([1, 0, 0, 0, 0])
    elif origin == "DTW":
        inputs.extend([0, 1, 0, 0, 0])
    elif origin == "JFK":
        inputs.extend([0, 0, 1, 0, 0])
    elif origin == "MSP":
        inputs.extend([0, 0, 0, 1, 0])
    elif origin == "SEA":
        inputs.extend([0, 0, 0, 0, 1])

    dest = str(request.form.get("dest"))
    if dest == "ATL":
        inputs.extend([1, 0, 0, 0, 0])
    elif dest == "DTW":
        inputs.extend([0, 1, 0, 0, 0])
    elif dest == "JFK":
        inputs.extend([0, 0, 1, 0, 0])
    elif dest == "MSP":
        inputs.extend([0, 0, 0, 1, 0])
    elif dest == "SEA":
        inputs.extend([0, 0, 0, 0, 1])

    prediction = preprocessAndPredict(inputs)
    print(inputs)
    return render_template('result.html', prediction=prediction)

def preprocessAndPredict(inputs):
    test_data = np.array(inputs).reshape((1, 16))
    
    # Load the model
    trained_model = joblib.load('D:/IDM/FLIGHT DELAY PREDICTION/flight.pkl')

    # Prepare DataFrame for prediction
    df = pd.DataFrame(data=test_data[0:, 0:], columns=[
        'FL_NUM', 'MONTH', 'DAY_OF_MONTH', 'DAY_OF_WEEK',
        'DEP_DEL15', 'CRS_ARR_TIME', 'ORIGIN_ATL', 
        'ORIGIN_DTW', 'ORIGIN_JFK', 'ORIGIN_MSP', 
        'ORIGIN_SEA', 'DEST_ATL', 'DEST_DTW', 
        'DEST_JFK', 'DEST_MSP', 'DEST_SEA'
    ])

    data = df.values
    result = trained_model.predict(data)
    print(result)
    return result

if __name__ == '__main__':
    app.run(debug=True)