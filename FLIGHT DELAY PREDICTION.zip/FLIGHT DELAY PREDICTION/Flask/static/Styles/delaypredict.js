function validateForm() {
    var fno = document.forms["flightForm"]["fno"].value;
    var month = document.forms["flightForm"]["month"].value;
    var daym = document.forms["flightForm"]["daym"].value;
    var dayw = document.forms["flightForm"]["dayw"].value;
    var org = document.forms["flightForm"]["org"].value;
    var dest = document.forms["flightForm"]["dest"].value;
    var sdt = document.forms["flightForm"]["sdt"].value; 
    var sat = document.forms["flightForm"]["sat"].value; 
    var adt = document.forms["flightForm"]["adt"].value; 
    
    if (fno == "" || fno == null || month == "" || month == null || daym == "" || daym == null || dayw == "" || dayw == null || org == "" || org == null || dest == "" || dest == null || sdt == "" || sdt == null || sat == "" || sat == null || adt == "" || adt == null) {
        alert("Please ensure all fields are filled out correctly.");
        event.preventDefault();
    }

    if(month < 1 || month > 12) {
        alert("Please enter a valid month (1-12).");
        event.preventDefault();
    }

    if(month == 2) {
        if(daym < 1 || daym > 28) {
            alert("Please enter a valid day for February (1-28).");
            event.preventDefault();
        }
    } else if([1, 3, 5, 7, 8, 10, 12].includes(Number(month))) {
        if(daym < 1 || daym > 31) {
            alert("Please enter a valid day for the selected month (1-31).");
            event.preventDefault();
        }
    } else if([4, 6, 9, 11].includes(Number(month))) {
        if(daym < 1 || daym > 30) {
            alert("Please enter a valid day for the selected month (1-30).");
            event.preventDefault();
        }
    }

    if(dayw < 1 || dayw > 7) {
        alert("Please enter a valid day of the week (1-7).");
        event.preventDefault();
    }

    if(org == dest) {
        alert("Origin and destination must be different.");
        event.preventDefault();
    }

    if(sdt < 500 || sdt > 2400) {
        alert("Please enter a valid departure time (500 to 2400).");
        event.preventDefault();
    }

    if(sat < 500 || sat > 2400) {
        alert("Please enter a valid arrival time (500 to 2400).");
        event.preventDefault();
    }

    if(sdt == sat) {
        alert("Departure and arrival times must differ by at least 1 hour.");
        event.preventDefault();
    }

    if(adt < 500 || adt > 2400) {
        alert("Please enter a valid actual departure time (500 to 2400).");
        event.preventDefault();
    }
}

function checkValid(element) {
    var obj = document.getElementById(element);
    var valid_obj = document.getElementById(element + "-valid");

    if (element == 'month') {
        if (obj.value < 1 || obj.value > 12) {
            obj.style.borderColor = "#FF4F4F";
            valid_obj.style.display = "block";
        } else {
            obj.style.borderColor = "#007BFF";
            valid_obj.style.display = "none";
        }
    }

    if (element == 'daym') {
        var monobj = document.getElementById('month');
        if (monobj.value == 2) {
            if (obj.value < 1 || obj.value > 28) {
                obj.style.borderColor = "#FF4F4F";
                valid_obj.style.display = "block";
            } else {
                obj.style.borderColor = "#007BFF";
                valid_obj.style.display = "none";
            }
        } else if ([1, 3, 5, 7, 8, 10, 12].includes(Number(monobj.value))) {
            if (obj.value < 1 || obj.value > 31) {
                obj.style.borderColor = "#FF4F4F";
                valid_obj.style.display = "block";
            } else {
                obj.style.borderColor = "#007BFF";
                valid_obj.style.display = "none";
            }
        } else if ([4, 6, 9, 11].includes(Number(monobj.value))) {
            if (obj.value < 1 || obj.value > 30) {
                obj.style.borderColor = "#FF4F4F";
                valid_obj.style.display = "block";
            } else {
                obj.style.borderColor = "#007BFF";
                valid_obj.style.display = "none";
            }
        }
    }

    if (element == 'dayw') {
        if (obj.value < 1 || obj.value > 7) {
            obj.style.borderColor = "#FF4F4F";
            valid_obj.style.display = "block";
        } else {
            obj.style.borderColor = "#007BFF";
            valid_obj.style.display = "none";
        }
    }

    if (element == 'dest') {
        var origin_obj = document.getElementById('org');
        if (obj.value == origin_obj.value) {
            obj.style.borderColor = "#FF4F4F";
            valid_obj.style.display = "block";
        } else {
            obj.style.borderColor = "#007BFF";
            valid_obj.style.display = "none";
        }
    }

    if (element == 'sdt') {
        if (obj.value < 500 || obj.value > 2400) {
            obj.style.borderColor = "#FF4F4F";
            valid_obj.style.display = "block";
        } else {
            obj.style.borderColor = "#007BFF";
            valid_obj.style.display = "none";
        }
    }

    if (element == 'sat') {
        if (obj.value < 500 || obj.value > 2400) {
            obj.style.borderColor = "#FF4F4F";
            valid_obj.style.display = "block";
        } else {
            obj.style.borderColor = "#007BFF";
            valid_obj.style.display = "none";
        }
    }

    if (element == 'adt') {
        if (obj.value < 500 || obj.value > 2400) {
            obj.style.borderColor = "#FF4F4F";
            valid_obj.style.display = "block";
        } else {
            obj.style.borderColor = "#007BFF";
            valid_obj.style.display = "none";
        }
    }
}